# API Futbol

Servidor realizado con Node.js y Express consumiendo datos de TheSportsDB.

## Instalacion

npm install

## Ejecutar servidor

node server.js

## Endpoints

/lpf
/messi
/arsenal
/clasico
/emisoras
/eventos
/alineaciones
/estadisticas