console.log("VERSION NUEVA");

const express = require("express");
const axios = require("axios");

const app = express();

const PORT = 3000;

app.use(express.json());


// =====================================
// RUTA PRINCIPAL
// =====================================

app.get("/", (req, res) => {

    res.send("Servidor funcionando");

});


// =====================================
// LIGA ARGENTINA
// =====================================

app.get("/lpf", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4406&s=2026"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// ULTIMO PARTIDO BOCA
// =====================================

app.get("/ultimo-partido-boca", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/eventslast.php?id=135156"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// PREMIOS MESSI
// =====================================

app.get("/premios-messi", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookuphonours.php?id=34146370"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// MESSI
// =====================================

app.get("/messi", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/searchplayers.php?p=Lionel_Messi"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// ARSENAL
// =====================================

app.get("/arsenal", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=Arsenal"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// BOCA VS RIVER
// =====================================

app.get("/clasico", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/searchevents.php?e=Boca_Juniors_vs_River_Plate"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// BOMBONERA
// =====================================

app.get("/bombonera", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/searchvenues.php?v=Estadio%20Alberto%20Jose%20Armando"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// DETALLES LPF
// =====================================

app.get("/detalles-lpf", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookupleague.php?id=4406"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// TABLA LPF
// =====================================

app.get("/tabla-lpf", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookuptable.php?l=4406"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// EQUIPO POR ID
// =====================================

app.get("/equipo/:id", async (req, res) => {

    try {

        const id = req.params.id;

        const response = await axios.get(
            `https://www.thesportsdb.com/api/v1/json/3/lookupteam.php?id=${id}`
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// EQUIPACION
// =====================================

app.get("/equipacion/:id", async (req, res) => {

    try {

        const id = req.params.id;

        const response = await axios.get(
            `https://www.thesportsdb.com/api/v1/json/3/lookupequipment.php?id=${id}`
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// EQUIPOS DE MESSI
// =====================================

app.get("/carrera-messi", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookupformerteams.php?id=34146370"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// HITOS MESSI
// =====================================

app.get("/hitos-messi", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookupmilestones.php?id=34146370"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// CONTRATOS MESSI
// =====================================

app.get("/contrato-messi", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookupcontracts.php?id=34146370"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// PARTIDO POR ID
// =====================================

app.get("/partido/:id", async (req, res) => {

    try {

        const id = req.params.id;

        const response = await axios.get(
            `https://www.thesportsdb.com/api/v1/json/3/lookupevent.php?id=${id}`
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// PSG VS BAYERN
// =====================================

app.get("/psg-bayern", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/searchevents.php?e=Bayern_Munich_vs_Paris_SG"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// ALINEACIONES
// =====================================

app.get("/alineaciones", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookuplineup.php?id=2466175"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// EVENTOS
// =====================================

app.get("/eventos", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookuptimeline.php?id=2466175"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// ESTADISTICAS
// =====================================

app.get("/estadisticas", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookupeventstats.php?id=2466175"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// EMISORAS
// =====================================

app.get("/emisoras", async (req, res) => {

    try {

        const response = await axios.get(
            "https://www.thesportsdb.com/api/v1/json/3/lookuptv.php?id=2466175"
        );

        res.json(response.data);

    } catch (error) {

        console.log(error.message);

        res.status(500).json({
            error: error.message
        });

    }

});


// =====================================
// LEVANTAR SERVIDOR
// =====================================

app.listen(PORT, () => {

    console.log(`Servidor funcionando en puerto ${PORT}`);

});